$(document).ready(function() {
    $('#autofill').click(function() {
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.executeScript(tabs[0].id, {
          code: `
            var net_tax_total = document.getElementById('net_tax_total');
            if (net_tax_total !== null) {
              net_tax_total.value = '123';
            }
          `
        });
      });
    });
  });