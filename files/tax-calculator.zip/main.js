const num1Input = document.getElementById("num1");
const num2Input = document.getElementById("num2");
const expensesOutput = document.getElementById("expenses");
const resultOutput = document.getElementById("result");
const calculateButton = document.querySelector("button");

chrome.storage.sync.get(["defaultNum1", "defaultNum2"], (result) => {
  num1Input.value = result.defaultNum1 || "";
  num2Input.value = result.defaultNum2 || "";
});

const saveValues = () => {
  chrome.storage.sync.set({
    defaultNum1: num1Input.value,
    defaultNum2: num2Input.value,
  });
};

function formatNumber(num) {
  const formattedNum = num.toString().replace(/[^0-9]/g, '');
  const parts = formattedNum.split('.');
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return parts.join('.');
}

function calculateTax() {
  const onGoingInput = document.getElementById("num1");
  const onGoing = parseInt(onGoingInput.value.replace(/[^\d]/g, ''));

  const exemptionInput = document.getElementById("num2");
  const exemption = parseInt(exemptionInput.value.replace(/[^\d]/g, ''));

  const expenses = Math.floor(onGoing * 0.07);
  const remaining = onGoing - exemption - expenses;
  const totalTax = Math.max(Math.floor(remaining * 0.1), 0);

  const expensesFormatted = formatNumber(expenses);
  const totalTaxFormatted = formatNumber(totalTax);

  const expensesOutput = document.getElementById("expenses");
  expensesOutput.innerHTML = `حق بیمه سهم کارگر :<br> ${expensesFormatted} ریال`;

  const resultOutput = document.getElementById("result");
  resultOutput.innerHTML = `مالیات قابل پرداخت :<br> ${totalTaxFormatted} ریال`;
}

const num1Element = document.getElementById('num1');
num1Element.addEventListener('input', function() {
  this.value = formatNumber(this.value);
});

const num2Element = document.getElementById('num2');
num2Element.addEventListener('input', function() {
  this.value = formatNumber(this.value);
});

calculateButton.addEventListener('click', calculateTax);
num1Input.addEventListener("input", saveValues);
num2Input.addEventListener("input", saveValues);